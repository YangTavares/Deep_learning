%load('last_generation');
%[out i] = min(fitness);
%plot(population{i}(:,1),population{i}(:,2));

load('last_generation');
[out i] = min(fitness);

j = 3;

x = 3.0;
y = 3.0;

[population{i}(j,1,:) population{i}(j,2,:)];
[x y];

qy = sign(y-population{i}(j,2,:));
qx = sign(x-population{i}(j,1,:));
%Third cartesian plan
if qx == -1 && qy == -1
    angle = (atan((y-population{i}(j,2,:))/(x-population{i}(j,1,:)))) - (pi/2);
    angle = (pi/2) + angle;
%Fourth cartesian plan
elseif qx == 1 && qy == -1
    angle = (atan((y-population{i}(j,2,:))/(x-population{i}(j,1,:))));
    angle = angle + pi;
%Second cartesian plan0
elseif qx == -1 && qy == 1
    angle = (pi/2) - (atan((y-population{i}(j,2,:))/(x-population{i}(j,1,:))));
    angle = (pi/2) - angle;
%First cartesian plan
elseif qx == 1 && qy == 1
    angle = (atan((y-population{i}(j,2,:))/(x-population{i}(j,1,:))));
    angle = angle - pi;
else
    angle = 0;
end
angle